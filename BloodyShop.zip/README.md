# BloodyShop Shop mod for VRising 

![alt text](https://github.com/oscarpedrero/BloodyShop/blob/master/Images/userui.png?raw=true)

Being the first public version of the mod, I would like you to help me with the feedback if you use it, for this I have created a Test template to perform and in case of finding any error, I would like you to leave everything you have been able to on issue find or new ideas.

[TESTTORUN.md](https://github.com/oscarpedrero/BloodyShop/blob/master/TESTTORUN.md) 

[Manual](https://github.com/oscarpedrero/BloodyShop/wiki/Manual)

[Known bugs](https://github.com/oscarpedrero/BloodyShop/wiki/Known-bugs)